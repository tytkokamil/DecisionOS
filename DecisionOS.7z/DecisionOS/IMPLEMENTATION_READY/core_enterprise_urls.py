"""
DecisionOS Enterprise URL Configuration
"""
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import (
    DecisionVersionViewSet,
    DecisionCommentViewSet,
    ReviewStepViewSet,
    ReviewerAssignmentViewSet,
    NotificationViewSet,
    DecisionAnalysisViewSet,
    AuditLogViewSet,
    dashboard,
    decision_detail,
    review_queue
)
# REST API Router
router = DefaultRouter()
router.register(r'versions', DecisionVersionViewSet, basename='version')
router.register(r'comments', DecisionCommentViewSet, basename='comment')
router.register(r'review-steps', ReviewStepViewSet, basename='reviewstep')
router.register(r'reviewer-assignments', ReviewerAssignmentViewSet, basename='assignment')
router.register(r'notifications', NotificationViewSet, basename='notification')
router.register(r'analytics', DecisionAnalysisViewSet, basename='analysis')
router.register(r'audit-logs', AuditLogViewSet, basename='auditlog')
# URL Patterns
urlpatterns = [
    # API Endpoints DATEI 4 von 11: core_enterprise_urls.py

    path('api/', include(router.urls)),
    
    # Dashboard Views
    path('dashboard/', dashboard, name='dashboard'),
    path('decision/<str:decision_id>/', decision_detail, name='decision_detail'),
    path('reviews/', review_queue, name='review_queue'),
]