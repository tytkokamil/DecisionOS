from django.contrib import admin
from decisions.models import *

# Import admin classes
from decisions.admin.template_admin import *
