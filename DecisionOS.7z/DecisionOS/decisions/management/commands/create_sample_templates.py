from django.core.management.base import BaseCommand
from decisions.models import TemplateCategory, DecisionTemplate, TemplateField
from django.contrib.auth import get_user_model

class Command(BaseCommand):
    help = 'Create sample templates'

    def handle(self, *args, **kwargs):
        User = get_user_model()
        admin = User.objects.filter(is_superuser=True).first()

        # Categories
        hiring = TemplateCategory.objects.get_or_create(
            name='Hiring',
            defaults={'icon': '👥', 'description': 'Candidate evaluation', 'order': 1}
        )[0]

        investment = TemplateCategory.objects.get_or_create(
            name='Investment',
            defaults={'icon': '💰', 'description': 'Investment decisions', 'order': 2}
        )[0]

        product = TemplateCategory.objects.get_or_create(
            name='Product',
            defaults={'icon': '🚀', 'description': 'Product development', 'order': 3}
        )[0]

        # Hiring Template
        hiring_template = DecisionTemplate.objects.get_or_create(
            name='Candidate Evaluation',
            defaults={
                'description': 'Evaluate job candidates with consistent criteria.',
                'category': hiring,
                'default_title_pattern': 'Hire: [Candidate Name] - [Position]',
                'default_description': 'Evaluate candidate qualifications and fit.',
                'visibility': 'public',
                'created_by': admin,
                'is_system_template': True
            }
        )[0]

        # Fields
        TemplateField.objects.get_or_create(
            template=hiring_template,
            label='Candidate Name',
            defaults={'field_type': 'text', 'is_required': True, 'order': 1}
        )
        
        TemplateField.objects.get_or_create(
            template=hiring_template,
            label='Position',
            defaults={'field_type': 'text', 'is_required': True, 'order': 2}
        )

        self.stdout.write(self.style.SUCCESS('✅ Sample templates created!'))
