"""
DecisionOS Enterprise - Django Settings (Development)
"""

from .base import *

# ============================================================================
# DEBUG & DEVELOPMENT
# ============================================================================
DEBUG = True
ALLOWED_HOSTS = ['*']

# ============================================================================
# INSTALLED APPS (ADD DEBUG TOOLBAR)
# ============================================================================
INSTALLED_APPS += [
    'django_extensions',
    'debug_toolbar',
]

# ============================================================================
# MIDDLEWARE (ADD DEBUG TOOLBAR)
# ============================================================================
MIDDLEWARE += [
    'debug_toolbar.middleware.DebugToolbarMiddleware',
]

# ============================================================================
# DEBUG TOOLBAR
# ============================================================================
INTERNAL_IPS = ['127.0.0.1']

# ============================================================================
# DATABASES (KEEP AS IS FOR LOCAL DEVELOPMENT)
# ============================================================================
DATABASES['default']['ATOMIC_REQUESTS'] = False

# ============================================================================
# LOGGING (VERBOSE FOR DEVELOPMENT)
# ============================================================================
LOGGING['loggers']['django']['level'] = 'DEBUG'
LOGGING['loggers']['core']['level'] = 'DEBUG'

# ============================================================================
# EMAIL (CONSOLE OUTPUT IN DEVELOPMENT)
# ============================================================================
EMAIL_BACKEND = 'django.core.mail.backends.console.EmailBackend'

# ============================================================================
# SECURITY (DISABLED FOR DEVELOPMENT)
# ============================================================================
SECURE_SSL_REDIRECT = False
SESSION_COOKIE_SECURE = False
CSRF_COOKIE_SECURE = False
SECURE_HSTS_SECONDS = 0

# ============================================================================
# CACHING (IN-MEMORY FOR DEVELOPMENT)
# ============================================================================
CACHES = {
    'default': {
        'BACKEND': 'django.core.cache.backends.locmem.LocMemCache',
        'LOCATION': 'unique-snowflake',
    }
}

# ============================================================================
# STATIC FILES
# ============================================================================
STATICFILES_STORAGE = 'django.contrib.staticfiles.storage.StaticFilesStorage'

# ============================================================================
# SENTRY (DISABLED)
# ============================================================================
# Nur aktivieren wenn du testen willst
# import sentry_sdk
# sentry_sdk.init(dsn=config('SENTRY_DSN', default=''))

print("✓ Development settings loaded")
