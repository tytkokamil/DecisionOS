"""
DecisionOS Enterprise - Django Settings (Production)
"""

from .base import *

# ============================================================================
# DEBUG & SECURITY
# ============================================================================
DEBUG = False
ALLOWED_HOSTS = config('ALLOWED_HOSTS', cast=Csv())

# ============================================================================
# SECURITY - STRICT IN PRODUCTION
# ============================================================================
SECURE_SSL_REDIRECT = True
SESSION_COOKIE_SECURE = True
CSRF_COOKIE_SECURE = True
SECURE_HSTS_SECONDS = 31536000  # 1 Jahr
SECURE_HSTS_INCLUDE_SUBDOMAINS = True
SECURE_HSTS_PRELOAD = True
SECURE_BROWSER_XSS_FILTER = True
SECURE_CONTENT_TYPE_NOSNIFF = True

# ============================================================================
# STATIC FILES
# ============================================================================
STATICFILES_STORAGE = 'whitenoise.storage.CompressedManifestStaticFilesStorage'

# ============================================================================
# DATABASE - PRODUCTION READY
# ============================================================================
DATABASES['default']['CONN_MAX_AGE'] = 600
DATABASES['default']['ATOMIC_REQUESTS'] = True

# ============================================================================
# LOGGING - PRODUCTION
# ============================================================================
LOGGING['handlers']['file']['filename'] = '/var/log/decisionos/django.log'

# ============================================================================
# EMAIL - REAL SMTP
# ============================================================================
EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
EMAIL_HOST = config('EMAIL_HOST')
EMAIL_PORT = config('EMAIL_PORT', cast=int)
EMAIL_USE_TLS = config('EMAIL_USE_TLS', cast=bool)
EMAIL_HOST_USER = config('EMAIL_HOST_USER')
EMAIL_HOST_PASSWORD = config('EMAIL_HOST_PASSWORD')

# ============================================================================
# SENTRY ERROR TRACKING
# ============================================================================
import sentry_sdk
from sentry_sdk.integrations.django import DjangoIntegration

sentry_dsn = config('SENTRY_DSN', default='')
if sentry_dsn:
    sentry_sdk.init(
        dsn=sentry_dsn,
        integrations=[DjangoIntegration()],
        traces_sample_rate=0.1,
        send_default_pii=False,
        environment='production'
    )

# ============================================================================
# ALLOWED HOSTS
# ============================================================================
ALLOWED_HOSTS = config('ALLOWED_HOSTS', cast=Csv())

print("✓ Production settings loaded - STRICT MODE ENABLED")
