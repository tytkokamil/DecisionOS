"""
DecisionOS Enterprise - WSGI Configuration
Für Gunicorn & Production
"""

import os
from django.core.wsgi import get_wsgi_application
from whitenoise import WhiteNoise

# Set default Django settings module
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings.production')

# Get WSGI application
application = get_wsgi_application()

# Wrap with WhiteNoise for static files
if os.environ.get('DJANGO_SETTINGS_MODULE', '').endswith('production'):
    application = WhiteNoise(application, root=os.path.join(os.path.dirname(__file__), '..', 'staticfiles'))
