from django.db.models import Count, Avg, Q, F
from django.utils import timezone
from datetime import timedelta
from .models import Decision, AuditLog, Team, Review

class AnalyticsService:
    """KPI calculations and analytics"""
    
    @staticmethod
    def get_team_kpis(team):
        """Calculate KPIs for team"""
        decisions = Decision.objects.filter(team=team)
        
        total = decisions.count()
        by_status = {item['status']: item['count'] for item in decisions.values('status').annotate(count=Count('id'))}
        
        # Average decision duration
        completed = decisions.filter(decision_date__isnull=False)
        avg_duration = None
        if completed.exists():
            durations = [d.duration_days() for d in completed]
            avg_duration = sum(durations) / len(durations) if durations else 0
        
        # Implementation rate
        implemented = decisions.filter(status='implemented').count()
        implementation_rate = (implemented / total * 100) if total > 0 else 0
        
        # Bottlenecks (in review > 7 days)
        week_ago = timezone.now() - timedelta(days=7)
        bottlenecks = decisions.filter(status='review', updated_at__lt=week_ago).count()
        
        # Pending reviews
        pending_reviews = Review.objects.filter(
            decision__team=team,
            status='pending'
        ).count()
        
        return {
            'total_decisions': total,
            'by_status': by_status,
            'avg_duration_days': round(avg_duration, 1) if avg_duration else 0,
            'implementation_rate': round(implementation_rate, 1),
            'bottlenecks': bottlenecks,
            'pending_reviews': pending_reviews,
            'draft': by_status.get('draft', 0),
            'review': by_status.get('review', 0),
            'approved': by_status.get('approved', 0),
            'implemented': by_status.get('implemented', 0),
        }
    
    @staticmethod
    def get_user_stats(user):
        """Get stats for user"""
        created = Decision.objects.filter(created_by=user).count()
        assigned = Decision.objects.filter(assigned_to=user).count()
        reviews_done = Review.objects.filter(reviewer=user, status__in=['approved', 'rejected']).count()
        reviews_pending = Review.objects.filter(reviewer=user, status='pending').count()
        
        return {
            'created': created,
            'assigned': assigned,
            'reviews_done': reviews_done,
            'reviews_pending': reviews_pending,
        }

analytics_service = AnalyticsService()
