from django.urls import path
from django.contrib.auth import views as auth_views
from . import views

app_name = 'decisions'

urlpatterns = [
    # Auth
    path('login/', auth_views.LoginView.as_view(template_name='decisions/login.html'), name='login'),
    path('logout/', auth_views.LogoutView.as_view(next_page='decisions:login'), name='logout'),
    
    # Dashboard
    path('', views.dashboard, name='dashboard'),
    
    # Decisions
    path('decision/create/', views.decision_create, name='decision_create'),
    path('decision/<int:pk>/', views.decision_detail, name='decision_detail'),
    path('decision/<int:pk>/edit/', views.decision_edit, name='decision_edit'),
    path('decision/<int:pk>/delete/', views.decision_delete, name='decision_delete'),
    
    # Workflow
    path('decision/<int:pk>/status/', views.decision_change_status, name='decision_change_status'),
    path('decision/<int:pk>/review/', views.decision_submit_review, name='decision_submit_review'),
    path('decision/<int:pk>/comment/', views.decision_add_comment, name='decision_add_comment'),
    
    # AI
    path('decision/<int:pk>/ai-analyze/', views.ai_analyze, name='ai_analyze'),
    
    # Team KPIs
    path('team/<int:team_id>/kpis/', views.team_kpis, name='team_kpis'),
]
