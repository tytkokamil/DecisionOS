const decisionId = window.location.pathname.match(/\/decisions\/(\d+)\//)?.[1];

function showAILoading() {
    document.getElementById('ai-results').classList.remove('hidden');
    document.getElementById('ai-loading').classList.remove('hidden');
    document.getElementById('ai-content').innerHTML = '';
}

function hideAILoading() {
    document.getElementById('ai-loading').classList.add('hidden');
}

async function aiAnalyze() {
    showAILoading();
    
    try {
        const response = await fetch(`/decisions/decisions/${decisionId}/ai/analyze/`, {
            method: 'POST',
            headers: {
                'X-CSRFToken': getCookie('csrftoken'),
                'Content-Type': 'application/json'
            }
        });
        
        const data = await response.json();
        hideAILoading();
        
        if (data.success) {
            displayAnalysis(data.analysis);
        }
    } catch (error) {
        hideAILoading();
        showError('Analysis failed. Check API key.');
    }
}

async function aiGenerateAlternatives() {
    showAILoading();
    
    try {
        const response = await fetch(`/decisions/decisions/${decisionId}/ai/alternatives/`, {
            method: 'POST',
            headers: {
                'X-CSRFToken': getCookie('csrftoken')
            }
        });
        
        const data = await response.json();
        hideAILoading();
        
        if (data.success) {
            displayAlternatives(data.alternatives);
        }
    } catch (error) {
        hideAILoading();
        showError('Failed to generate alternatives.');
    }
}

async function aiGenerateSummary() {
    showAILoading();
    
    try {
        const response = await fetch(`/decisions/decisions/${decisionId}/ai/summary/`, {
            method: 'POST',
            headers: {
                'X-CSRFToken': getCookie('csrftoken')
            }
        });
        
        const data = await response.json();
        hideAILoading();
        
        if (data.success) {
            displaySummary(data.summary);
        }
    } catch (error) {
        hideAILoading();
        showError('Failed to generate summary.');
    }
}

function displayAnalysis(analysis) {
    const insights = analysis.insights.map(i => `<li class="text-gray-700">• ${i}</li>`).join('');
    const risks = analysis.risks.map(r => `
        <div class="border-l-4 border-red-500 pl-3 py-1 mb-2">
            <div class="font-medium">${r.risk}</div>
            <div class="text-sm text-gray-600">${r.impact}</div>
        </div>
    `).join('');
    const recs = analysis.recommendations.map(r => `<li>• ${r}</li>`).join('');
    
    document.getElementById('ai-content').innerHTML = `
        <h3 class="text-lg font-bold mb-4">📊 AI Analysis</h3>
        <div class="mb-4">
            <h4 class="font-semibold mb-2">💡 Insights</h4>
            <ul>${insights}</ul>
        </div>
        <div class="mb-4">
            <h4 class="font-semibold mb-2">⚠️ Risks</h4>
            ${risks}
        </div>
        <div>
            <h4 class="font-semibold mb-2">✅ Recommendations</h4>
            <ul>${recs}</ul>
        </div>
    `;
}

function displayAlternatives(alternatives) {
    const html = alternatives.map((alt, i) => `
        <div class="border rounded-lg p-4 mb-3">
            <h4 class="font-semibold mb-2">${i + 1}. ${alt.title}</h4>
            <p class="mb-2">${alt.description}</p>
            <div class="grid grid-cols-2 gap-2 text-sm">
                <div>
                    <strong>Pros:</strong>
                    <ul>${alt.pros.map(p => `<li>• ${p}</li>`).join('')}</ul>
                </div>
                <div>
                    <strong>Cons:</strong>
                    <ul>${alt.cons.map(c => `<li>• ${c}</li>`).join('')}</ul>
                </div>
            </div>
        </div>
    `).join('');
    
    document.getElementById('ai-content').innerHTML = `
        <h3 class="text-lg font-bold mb-4">💡 Alternatives</h3>
        ${html}
    `;
}

function displaySummary(summary) {
    document.getElementById('ai-content').innerHTML = `
        <h3 class="text-lg font-bold mb-4">📄 Executive Summary</h3>
        <p class="whitespace-pre-line">${summary}</p>
    `;
}

function showError(message) {
    document.getElementById('ai-content').innerHTML = `
        <div class="text-red-600">⚠️ ${message}</div>
    `;
}

function getCookie(name) {
    let cookieValue = null;
    if (document.cookie) {
        const cookies = document.cookie.split(';');
        for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i].trim();
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}